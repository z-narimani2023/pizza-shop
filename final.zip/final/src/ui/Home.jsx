import { useSelector } from 'react-redux';
import CreateUser from '../features/user/CreateUser';
import Button from './Button';

function Home() {
  const username = useSelector((state) => state.user.username);

  return (
    <div className="my-10 px-4 text-center sm:my-16">
      <h1 className="font-custom  mb-8 text-xl md:text-3xl">
        پیتزا 2000
        <br />
        <br />
        <span className="font-custom text-yellow-500">
          مستقیماً از فر، مستقیماً برای شما
        </span>
      </h1>

      {username === '' ? (
        <CreateUser />
      ) : (
        <Button to="/menu" type="primary">
          ادامه سفارش {username}
        </Button>
      )}
    </div>
  );
}

export default Home;
